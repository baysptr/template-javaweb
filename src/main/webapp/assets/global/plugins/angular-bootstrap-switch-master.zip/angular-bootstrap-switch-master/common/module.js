'use strict';

angular.module('frapontillo.bootstrap-switch', []);
