'use strict';

angular.module('bsSwitchApp', ['frapontillo.bootstrap-switch']);
